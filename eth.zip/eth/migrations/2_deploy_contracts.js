var Bid = artifacts.require("Bid.sol");

module.exports = function(deployer) {
  deployer.deploy(Bid);
};
